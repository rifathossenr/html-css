<h1>Georgia</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | First Channel (1TV)  | [>](https://tv.cdn.xsg.ge/gpb-1tv/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0d/Pirveli_Arkhi_Logo_2022.svg/512px-Pirveli_Arkhi_Logo_2022.svg.png"/> | 1TV.ge |
| 2   | First Channel /Education/ (2TV)  | [>](https://tv.cdn.xsg.ge/gpb-2tv/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/ka/c/c9/2_Tv_Logo.jpg"/> | 2TV.ge |
| 3   | Imedi TV | [>](https://tv.cdn.xsg.ge/imedihd/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Imlogo_2020.png"/> | ImediTV.ge |
| 4   | Rustavi 2 | [>](https://sktv-forwarders.7m.pl/get.php?x=Rustavi2) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/f/f8/Rustavi_2_logo.png"/> | Rustavi2.ge |
| 5   | Mtavari Arkhi | [>](https://bozztv.com/36bay2/mtavariarxi/playlist.m3u8) | <img height="20" src="https://i.imgur.com/tLtGnJW.png"/> | MtavariArkhi.ge |
| 6   | GDS | [x]() | <img height="20" src="https://i.imgur.com/gv61tFf.png"/> | GDSTV.ge |
| 7   | TV Pirveli | [x]() | <img height="20" src="https://i.imgur.com/cGHsM1x.png"/> | TVPirveli.ge |
| 8   | Formula | [>](https://c4635.cdn.xsg.ge/c4635/TVFormula/index.m3u8) | <img height="20" src="https://i.imgur.com/fsqBn8G.png"/> | Formula.ge |
| 9   | Pos TV | [>](https://live.postv.media/stream/index.m3u8) | <img height="20" src="https://i.imgur.com/UOiXFEW.png"/> | PosTV.ge |
| 10   | Adjara TV | [x]() | <img height="20" src="https://i.imgur.com/UOiXFEW.png"/> | AjaraTV.ge |
| 11   | Maestro TV | [x]() | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/d/d5/Maestro_tv.png"/> | Maestro.ge |
| 11   | Obieqtivi | [x]() | <img height="20" src="https://i.imgur.com/Kqc8H8X.png"/> | ObieqtiviTV.ge |
| 999  | Euronews Georgia Ⓖ | [>](https://live2.tvg.ge/eng/EURONEWSGEORGIA/playlist.m3u8) | <img height="20" src="https://i.imgur.com/VNJ4soR.png"/> | EuroNewsGeorgia.ge |
