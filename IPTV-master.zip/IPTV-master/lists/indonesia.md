<h1>Indonesia</h1>

| # |   Channel    |                                    Link                                     |                           Logo                           |     EPG id     |
|:-:|:------------:|:---------------------------------------------------------------------------:|:--------------------------------------------------------:|:--------------:|
| 1 |  CNBC Indonesia | [>](https://live.cnbcindonesia.com/livecnbc/smil:cnbctv.smil/chunklist.m3u8) | <img height="20" src="https://imgur.com/ie2zSTY"/> |  CNBCIndonesia.am   |
| 2 | CNN Indonesia | [>](http://live.cnnindonesia.com/livecnn/smil:cnntv.smil/playlist.m3u8) | <img height="20" src="https://imgur.com/MpxTMiP"/> | CNNIndonesia.am  |
| 3 | BeritaSatu  | [>](https://b1news.beritasatumedia.com/Beritasatu/B1News_1280x720.m3u8) | <img height="20" src="https://imgur.com/vYJVT07"/> | BeritaSatu.am |