<h1>Chad</h1>

<h2>DVB-S</h2>

* https://www.lyngsat.com/freetv/Chad.html

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | Tchad 24 | [>](http://102.131.58.110/out_1/index.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/tt/tchad-24-td.png"/> | Tchad24.td |
| 0   | Télé Tchad Ⓢ | [>](https://strhlslb01.streamakaci.tv/str_tchad_tchad/str_tchad_multi/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/fr/b/b6/Logo_T%C3%A9l%C3%A9_Tchad.png"/> | TeleTchad.td |
