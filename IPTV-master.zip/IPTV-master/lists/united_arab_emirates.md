<h1>United Arab Emirates</h1>

* https://www.lyngsat.com/freetv/United-Arab-Emirates.html
* https://en.kingofsat.tv/find2.php?pos=&cl=&num_pays=50&num_genre=&num_crypt=1&num_standard=&ordre=freq (other than Abu Dhabi, Dubai or Sharjah)

| #  |        Channel         |                                                                                               Link                                                                                               |                                                     Logo                                                     |                  EPG id                  |
|:--:|:----------------------:|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------:|:------------------------------------------------------------------------------------------------------------:|:----------------------------------------:|
| 1  | Cartoon Network Arabic |                                               [>](https://shls-cartoon-net-prod-dub.shahid.net/out/v1/dc4aa87372374325a66be458f29eab0f/index.m3u8)                                               | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/b/bb/Cartoon_Network_Arabic_logo.png"/> |         CartoonNetworkArabic.ae          |
| 2  |  Al Arabiya Business   |                                                            [>](https://live.alarabiya.net/alarabiapublish/aswaaq.smil/playlist.m3u8)                                                             |                           <img height="20" src="https://i.imgur.com/eEV4r6J.jpg"/>                           |           AlArabiyaBusiness.ae           |
| 3  |         MBC 1          |                                                     [>](https://mbc1-enc.edgenextcdn.net/out/v1/0965e4d7deae49179172426cbfb3bc5e/index.m3u8)                                                     |                           <img height="20" src="https://i.imgur.com/CiA3plN.png"/>                           |                 MBC1.ae                  |
| 4  |        MBC 2 Ⓢ         |                                                                       [>](http://37.122.156.107:4000/play/a07g/index.m3u8)                                                                       |                           <img height="20" src="https://i.imgur.com/n9mSHuP.png"/>                           |                 MBC2.ae                  |
| 5  |         MBC 3          |                                                  [>](https://shls-mbc3-prod-dub.shahid.net/out/v1/d5bbe570e1514d3d9a142657d33d85e6/index.m3u8)                                                   |                           <img height="20" src="https://i.imgur.com/PVt8OPN.png"/>                           |                 MBC3.ae                  |
| 6  |         MBC 4          |                                                  [>](https://mbc4-prod-dub-ak.akamaized.net/out/v1/c08681f81775496ab4afa2bac7ae7638/index.m3u8)                                                  |                           <img height="20" src="https://i.imgur.com/BcXASJp.png"/>                           |                 MBC4.ae                  |
| 7  |         MBC 5          |                                                  [>](https://shls-mbc5-prod-dub.shahid.net/out/v1/2720564b6a4641658fdfb6884b160da2/index.m3u8)                                                   |                           <img height="20" src="https://i.imgur.com/fRWaDyF.png"/>                           |                 MBC5.ae                  |
| 8  |      MBC Action Ⓢ      |                                                                       [>](http://37.122.156.107:4000/play/a07h/index.m3u8)                                                                       |                           <img height="20" src="https://i.imgur.com/OWZAghw.png"/>                           |               MBCAction.ae               |
| 9  |     MBC Bollywood      |                                              [>](https://shls-mbcbollywood-prod-dub.shahid.net/out/v1/a79c9d7ef2a64a54a64d5c4567b3462a/index.m3u8)                                               |                           <img height="20" src="https://i.imgur.com/TTAGFHG.png"/>                           |             	MBCBollywood.ae             |
| 10 |       MBC Drama        |                                                     [>](https://mbc1-enc.edgenextcdn.net/out/v1/b0b3a0e6750d4408bb86d703d5feffd1/index.m3u8)                                                     |                           <img height="20" src="https://i.imgur.com/g5PWnqp.png"/>                           |              		MBCDrama.ae               |
| 11 |       MBC Max Ⓢ        |                                                                       [>](http://37.122.156.107:4000/play/a07i/index.m3u8)                                                                       |                           <img height="20" src="https://i.imgur.com/A02CptP.png"/>                           |              				MBCMax.ae               |
| 12 |       MBC Persia       |                                                [>](https://shls-mbcpersia-prod-dub.shahid.net/out/v1/bdc7cd0d990e4c54808632a52c396946/index.m3u8)                                                |                           <img height="20" src="https://i.imgur.com/4FXiyjn.png"/>                           |            					MBCPersia.ae             |
| 13 |        Wanasah         |                                                 [>](https://shls-wanasah-prod-dub.shahid.net/out/v1/c84ef3128e564b74a6a796e8b6287de6/index.m3u8)                                                 |                           <img height="20" src="https://i.imgur.com/nLtiXNf.png"/>                           |              				Wanasah.ae              |
| 14 |    Sky News Arabia     |                                                                        [>](https://stream.skynewsarabia.com/hls/sna.m3u8)                                                                        |                           <img height="20" src="https://i.imgur.com/SvjU4h6.png"/>                           |          					SkyNewsArabia.ae           |
| 15 |    Baynounah TV     |                                                         [>](https://vo-live.cdb.cdn.orange.com/Content/Channel/Baynounah/HLS/index.m3u8)                                                         |    <img height="20" src="https://static.wikia.nocookie.net/logopedia/images/6/60/Baynounah_tv_2023.png"/>    |          					BaynounahTV.ae          |
| 16 |    Ajman TV     |                                                  [>](https://dacastmmd.mmdlive.lldns.net/dacastmmd/8eb0e912b49142d7a01d779c9374aba9/index.m3u8)                                                  |    <img height="20" src="https://pbs.twimg.com/profile_images/1085187553563561990/KRKuK_iW_400x400.jpg"/>    |          					AjmanTV.ae          |
| 17 |    Al Aan TV     |                                                  [>](https://shls-live-ak.akamaized.net/out/v1/dfbdea4c1bf149629764e58c6ff314c8/index.m3u8)                                                  |    <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/7/76/Al_Aan_TV_new_Logo.png"/>    |          					AlAanTV.ae          |

<h2>Abu Dhabi</h2>

* https://en.kingofsat.tv/find2.php?pos=&cl=&num_pays=52&num_genre=&num_crypt=1&num_standard=&ordre=freq

| #   |            Channel            | Link  | Logo | EPG id |
|:---:|:-----------------------------:|:-----:|:----:|:------:|
| 1   |         Abu Dhabi TV          | [>](http://admdn2.cdn.mangomolo.com/adtv/smil:adtv.stream.smil/chunklist.m3u8) | <img height="20" src="https://i.imgur.com/7cNke07.png"/> | AbuDhabiTV.ae |
| 2   |      Abu Dhabi Sports 1       | [>](https://vo-live.cdb.cdn.orange.com/Content/Channel/AbuDhabiSportsChannel1/HLS/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Abu_Dhabi_Sports_logo_2023.svg/2560px-Abu_Dhabi_Sports_logo_2023.svg.png"/> | AbuDhabiSports2.ae |
| 3   |      Abu Dhabi Sports 2       | [>](https://vo-live.cdb.cdn.orange.com/Content/Channel/AbuDhabiSportsChannel2/HLS/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Abu_Dhabi_Sports_logo_2023.svg/2560px-Abu_Dhabi_Sports_logo_2023.svg.png"/> | AbuDhabiSports2.ae |
| 4   | National Geographic Abu Dhabi | [>](https://admdn2.cdn.mangomolo.com/nagtv/smil:nagtv.stream.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/fNA00VF.png"/> | NationalGeographicAbuDhabi.ae |

<h2>Ajman</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Ajman TV | [>](https://dacastmmd.mmdlive.lldns.net/dacastmmd/8eb0e912b49142d7a01d779c9374aba9/index.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/aa/ajman-tv-ae.png"/> | AjmanTV.ae |

<h2>Dubai</h2>

* https://en.kingofsat.tv/find2.php?pos=&cl=&num_pays=49&num_genre=&num_crypt=1&num_standard=&ordre=freq

| #  |    Channel     | Link  | Logo | EPG id |
|:--:|:--------------:|:-----:|:----:|:------:|
| 1  |    Dubai TV    | [>](https://dmisxthvll.cdn.mgmlcdn.com/dubaitvht/smil:dubaitv.stream.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/wZMkKF7.png"/> | DubaiTV.ae |
| 2  |   Dubai One    | [>](https://dminnvll.cdn.mangomolo.com/dubaione/smil:dubaione.stream.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/7/7d/Dubaione-logo.png"/> | DubaiOne.ae |
| 3  | Dubai Sports 1 | [>](https://dmitnthfr.cdn.mgmlcdn.com/dubaisports/smil:dubaisports.stream.smil/chunklist.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/dd/dubai-sports-ae.png"/> | DubaiSports1.ae |
| 4  | Dubai Sports 2 | [>](https://dmitwlvvll.cdn.mangomolo.com/dubaisportshd/smil:dubaisportshd.smil/index.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/dd/dubai-sports-ae.png"/> | DubaiSports2.ae |
| 5  | Dubai Sports 3 | [>](https://dmitwlvvll.cdn.mangomolo.com/dubaisportshd5/smil:dubaisportshd5.smil/index.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/dd/dubai-sports-ae.png"/> | DubaiSports3.ae |
| 6  | Dubai Racing 1 | [>](https://dmisvthvll.cdn.mgmlcdn.com/events/smil:events.stream.smil/playlist.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/dd/dubai-racing-ae.png"/> | DubaiRacing1.ae |
| 7  | Dubai Racing 2 | [>](https://dmithrvll.cdn.mangomolo.com/dubairacing/smil:dubairacing.smil/playlist.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/dd/dubai-racing-ae.png"/> | DubaiRacing2.ae |
| 8  | Dubai Racing 3 | [>](https://dmithrvll.cdn.mangomolo.com/dubaimubasher/smil:dubaimubasher.smil/playlist.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/dd/dubai-racing-ae.png"/> | DubaiRacing3.ae |
| 9  |  Dubai Zaman   | [>](https://dmiffthvll.cdn.mangomolo.com/dubaizaman/smil:dubaizaman.stream.smil/playlist.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/dd/dubai-zaman-ae.png"/> | DubaiZaman.ae |
| 10 |   Sama Dubai   | [>](https://dmieigthvll.cdn.mgmlcdn.com/samadubaiht/smil:samadubai.stream.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/bF6I3N1.jpg"/> | SamaDubai.ae |
| 11 |   Noor Dubai   | [>](https://dmiffthvll.cdn.mangomolo.com/noordubaitv/smil:noordubaitv.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/DLe7ZuM.png"/> | NoorDubai.ae |

<h2>Fujairah</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Fujairah TV | [x]() | <img height="20" src="https://www.lyngsat.com/logo/tv/ff/fujairah-tv-ae.png"/> | FujairahTV.ae |


<h2>Sharjah</h2>

* https://en.kingofsat.tv/find2.php?pos=&cl=&num_pays=53&num_genre=&num_crypt=1&num_standard=&ordre=freq

| # | Channel        | Link  | Logo |      EPG id      |
|:-:|:--------------:|:-----:|:----:|:----------------:|
| 1 | Sharjah TV | [>](https://svs.itworkscdn.net/smc1live/smc1.smil/playlist.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/ss/sharjah-tv-ae.png"/> |   SharjahTV.ae   |
| 2 | Sharjah Sports | [>](https://svs.itworkscdn.net/smc4sportslive/smc4.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/IaRaabJ.jpg"/> | SharjahSports.ae |
| 3 | Al Wousta | [>](https://svs.itworkscdn.net/alwoustalive/alwoustatv.smil/playlist.m3u8) | <img height="20" src="https://i5.satexpat.com/cha/ae/al-wousta-95x90.gif"/> | SharjahSports.ae |

