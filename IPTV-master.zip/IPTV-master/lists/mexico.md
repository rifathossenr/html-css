<h1>Mexico</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
|1    | Alcarria TV    |[>](http://cls.alcarria.tv/live/alcarriatv-livestream.m3u8) | <img height="20" src="https://i.imgur.com/zNSuxVZ.jpg"/> | AlcarriaTV.es |
|2    | Hipodromo de las Americas |[>](http://wms30.tecnoxia.com/soelvi/abr_soelvi/playlist.m3u8) | <img height="20" src="https://i.imgur.com/wc8MlGw.png"/> | HipodromodelasAmericas.mx |
|3    | MVM NoticiasⓈ   |[>](http://dcunilive21-lh.akamaihd.net/i/dclive_1@59479/index_1_av-p.m3u8) | <img height="20" src="https://i.imgur.com/dhLXN9n.png"/> | MVMNoticias.mx |
|4    | RCG 3 Saltillo |[>](http://wowzacontrol.com:1936/stream56/stream56/playlist.m3u8) | <img height="20" src="https://i.imgur.com/NefH5qZ.png"/> | RCGTV3.mx |
|5    | TeleFormula    |[>](https://wms60.tecnoxia.com/radiof/abr_radioftele/playlist.m3u8) | <img height="20" src="https://i.imgur.com/jR6taXt.png"/> | TeleFormula.mx |
|6    | NRT 4 Monclova |[>](https://59e88b197fb16.streamlock.net:4443/live/canal4/playlist.m3u8) | <img height="20" src="https://i.imgur.com/IudKE0n.png"/> | noticiasnrt.com |
|7| Las Estrellas |[>](https://linear-416.frequency.stream/416/hls/master/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/4/41/Las_Estrellas.svg"/> | Lasestrellas.tv |
