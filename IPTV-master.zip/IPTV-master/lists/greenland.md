<h1>Greenland</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | KNR1 Ⓨ Ⓖ | [>](https://www.youtube.com/@KNRgreenland/live) | <img height="20" src="https://i.imgur.com/8Pf5SJb.png"/> | KNR1.gl |
| 2   | KNR2 Ⓨ | [>](https://www.youtube.com/@nutaarsiassat/live) | <img height="20" src="https://i.imgur.com/8Pf5SJb.png"/> | KNR2.gl |
