<h1>Armenia</h1>

| # |   Channel    |                                    Link                                     |                           Logo                           |     EPG id     |
|:-:|:------------:|:---------------------------------------------------------------------------:|:--------------------------------------------------------:|:--------------:|
| # |  Armenia 1   |          [>](https://amtv1.livestreamingcdn.com/am2abr/index.m3u8)          | <img height="20" src="https://i.imgur.com/HIwJ4lc.png"/> |  Armenia1.am   |
| # | Kentron TV Ⓢ | [>](https://gineu9.bozztv.com/gin-36bay2/gin-kentron/tracks-v1a1/mono.m3u8) | <img height="20" src="https://i.imgur.com/eCaxBFn.png"/> | 	KentronTV.am  |
| # | Armenia TV Ⓢ  | [>](https://cdn.hayastantv.com:8088/armenia/tracks-v1a1/mono.m3u8) | <img height="20" src="https://i.imgur.com/UnoI5uM.png"/> | 		ArmeniaTV.am |
| # | 5TV Ⓢ  | [>](https://cdn.hayastantv.com:8088/5tv/tracks-v1a1/mono.m3u8) | <img height="20" src="https://i.imgur.com/jOGZZDo.png"/> |   			5TV.am    |