<h1>Canada</h1>

<h2>English</h2>

| #   | Channel         | Link  | Logo | EPG id |
|:---:|:---------------:|:-----:|:----:|:------:|
| 1   | CBC Toronto     | [>](https://bozztv.com/teleyupp1/teleup-ydcl2V1MVC/playlist.m3u8) | <img height="20" src="https://i.imgur.com/H5yEbxf.png"/> | CBCTDT.ca |
| 2   | Citytv          | [>](https://bozztv.com/teleyupp1/teleup-iSykLSKMFr/tracks-v1a1/mono.m3u8) | <img height="20" src="https://i.imgur.com/BlFNlHz.png"/> | 
| 3   | CTV Toronto     | [>](https://bozztv.com/teleyupp1/teleup-zxsJFt6VvY/playlist.m3u8) | <img height="20" src="https://i.imgur.com/qOutOWN.png"/> |
| 4   | Global Toronto  | [>](https://d128o1k7zh3htz.cloudfront.net/out/v1/74a58360a3734f97b74ba439bc678044/index.m3u8) | <img height="20" src="https://i.imgur.com/2CxLO4H.png"/> |
| 5   | Global Calgary  | [>](https://dfmjr9irb1dl5.cloudfront.net/out/v1/454010ff309e4963a087f5802856e346/index.m3u8) | <img height="20" src="https://i.imgur.com/2CxLO4H.png"/> |
| 6   | Global Edmonton | [>](https://da7sdtkzly6qj.cloudfront.net/out/v1/b317f6c10f2e493993bd2b5314df1c7c/index_1.m3u8) | <img height="20" src="https://i.imgur.com/2CxLO4H.png"/> |
| 8   | TVO             | [>](https://bozztv.com/teleyupp1/teleup-OMZsmYVUMp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/PkBPPcL.png"/> |
| 9   | CTV 2           | [x]() | <img height="20" src=""/> |
| 10  | Great Western   | [x]() | <img height="20" src=""/> |
| 11  | Yes TV          | [x]() | <img height="20" src=""/> |
| 12  | NTV             | [>](http://152.89.62.111:8080/nXyAiP3DNp/QgOuvocpGv/223012) | <img height="20" src="https://i.imgur.com/b8W3Aah.png"/> |
| 13  | CHCH            | [>](http://152.89.62.111:8080/nXyAiP3DNp/QgOuvocpGv/222841) | <img height="20" src="https://i.imgur.com/jYSXaga.png"/> |
| 14  | CHECK           | [x]() | <img height="20" src=""/> |
| 15  | ONNtv Ontario   | [>](https://onntv.vantrix.tv:443/onntv_hls/1080p/onntv_hls-HLS-1080p.m3u8) | <img height="20" src="https://i.imgur.com/zz5ST9K.png"/> | ONNtv.ca |
| 16  | Star TV         | [>](http://live.canadastartv.com:1935/canadastartv/canadastartv/playlist.m3u) | <img height="20" src="https://i.imgur.com/Ap54LCC.png"/> |
| 17  | CBC News        | [>](https://cbcnewshd-f.akamaihd.net/i/cbcnews_1@8981/index_2500_av-p.m3u8) | <img height="20" src="https://i.imgur.com/1EqQGKS.png"/> | CBCNewsNetwork.ca |
| 18  | CTV News        | [>](https://pe-fa-lp02a.9c9media.com/live/News1Digi/p/hls/00000201/38ef78f479b07aa0/index/0c6a10a2/live/stream/h264/v1/3500000/manifest.m3u8) | <img height="20" src="https://i.imgur.com/T3oBeiX.png"/> | CTVNewsChannel.ca |
| 19  | Global News     | [>](https://i.mjh.nz/PlutoTV/62cbef9ebb857100072fc187-alt.m3u8) | <img height="20" src="https://i.imgur.com/IpfmG93.png"/> |
| 20  | Global News BC  | [>](https://i.mjh.nz/PlutoTV/62cbf063257170000724590c-alt.m3u8) | <img height="20" src="https://i.imgur.com/IpfmG93.png"/> | CHANDT.ca |
| 21  | Global News Calgary      | [>](https://i.mjh.nz/PlutoTV/62cbf23dcfb48300077f8348-alt.m3u8) | <img height="20" src="https://i.imgur.com/IpfmG93.png"/> | CICTDT.ca |
| 22  | Global News Halifax      | [>](https://i.mjh.nz/PlutoTV/62cbf398b8e02600071deda5-alt.m3u8) | <img height="20" src="https://i.imgur.com/IpfmG93.png"/> |
| 23  | Global News Kingston     | [>](https://i.mjh.nz/PlutoTV/62cbf4964446e2000742073e-alt.m3u8) | <img height="20" src="https://i.imgur.com/IpfmG93.png"/> | CKWSDT.ca |
| 24  | Global News Montreal     | [>](https://i.mjh.nz/PlutoTV/62cbfbd6ad95670007f567af-alt.m3u8) | <img height="20" src="https://i.imgur.com/IpfmG93.png"/> |
| 25  | Global News Peterborough | [>](https://i.mjh.nz/PlutoTV/62cbfcd8c2db990007861e43-alt.m3u8) | <img height="20" src="https://i.imgur.com/IpfmG93.png"/> | CHEXDT.ca |
| 26  | Global News Regina       | [>](https://i.mjh.nz/PlutoTV/62cbff53ca8f2200080253b5-alt.m3u8) | <img height="20" src="https://i.imgur.com/IpfmG93.png"/> | CFREDT.ca |
| 27  | Global News Saskatoon    | [>](https://i.mjh.nz/PlutoTV/62cc00359cb58900088dc840-alt.m3u8) | <img height="20" src="https://i.imgur.com/IpfmG93.png"/> | CFSKDT.ca |
| 28  | Global News Vancouver    | [x](https://d8i9f8op7jmyk.cloudfront.net/out/v1/89a3f0453e134472a2101f6264d055ae/index.m3u8) | <img height="20" src="https://i.imgur.com/IpfmG93.png"/> |
| 29  | Global News Winnipeg     | [>](https://i.mjh.nz/PlutoTV/62cc0120880c890007191016-alt.m3u8) | <img height="20" src="https://i.imgur.com/IpfmG93.png"/> | CKNDDT.ca |
| 30  | CPAC (EN)       | [>](https://d7z3qjdsxbwoq.cloudfront.net/groupa/live/f9809cea-1e07-47cd-a94d-2ddd3e1351db/live.isml/.m3u8) | <img height="20" src="https://i.imgur.com/AbdFD0S.png"/> | CPACEnglish.ca |

<h2>French</h2>

| #   | Channel      | Link   | Logo | EPG id |
|:---:|:------------:|:------:|:----:|:------:|
| 1   | ICI RDI      | [>](https://rcavlive.akamaized.net/hls/live/704025/xcanrdi/master.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0a/ICI_RDI_logo.svg/640px-ICI_RDI_logo.svg.png"/> | IciRDI.ca |
| 2   | ICI Télé HD Ⓖ | [>](https://rcavlive.akamaized.net/hls/live/696615/xcancbft/master.m3u8) | <img height="20" src="https://i.imgur.com/HsSi3NV.png"/> |
| 3   | TVA Ⓖ       | [>](https://tvalive.akamaized.net/hls/live/2012413/tva01/master.m3u8) | <img height="20" src="https://i.imgur.com/1GR8Szn.png"/> |
| 4   | Noovo        | [>](https://pe-ak-lp04a-9c9media.akamaized.net/live/NOOVO/p/dash/00000001/f481c583dbd06b6c/manifest.mpd) | <img height="20" src="https://i.imgur.com/BL9ziSJ.png"/> |
| 5   | Télé Québec  | [>](https://bcovlive-a.akamaihd.net/575d86160eb143458d51f7ab187a4e68/us-east-1/6101674910001/playlist.m3u8) | <img height="20" src="https://i.imgur.com/8grBWK9.png"/> | CIVMDT.ca |
| 6   | Savoir Média | [>](https://hls.savoir.media/live/stream.m3u8) | <img height="20" src="https://i.imgur.com/pa4wOVY.png"/> | CFTUDT.ca |
| 7   | CPAC (FR)    | [>](https://bcsecurelivehls-i.akamaihd.net/hls/live/680604/1242843915001_3/master.m3u8) | <img height="20" src="https://i.imgur.com/AbdFD0S.png"/> | CPACFrench.ca |


<h2>Multilingual</h2>

| #   | Channel           | Link   | Logo | EPG id |
|:---:|:-----------------:|:------:|:----:|:------:|
| 1   | APTN              | [x]() | <img height="20" src="https://i.imgur.com/S213Hyb.png"/> |
| 2   | Omni Television   | [x]() | <img height="20" src=""/> |
| 3   | ICI Montreal    | [>](https://amdici.akamaized.net/hls/live/873426/ICI-Live-Stream/master.m3u8) | <img height="20" src="https://i.imgur.com/Z1b2TJD.png"/> | CBFTDT.ca |
| 4   | Toronto 360 TV   | [>](http://cdn3.toronto360.tv:8081/toronto360/hd/playlist.m3u8) | <img height="20" src="https://i.imgur.com/PkWndsv.png"/> | Toronto360.tv |
