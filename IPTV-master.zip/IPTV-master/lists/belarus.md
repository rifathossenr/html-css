<h1>Belarus</h1>

<h2>DVB-T</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Беларусь 1 | [>](https://ngtrk.dc.beltelecom.by/ngtrk/smil:belarus1.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/Belarus_1_logo.svg/742px-Belarus_1_logo.svg.png"/> | Belarus1.by |
| 0   | Беларусь 2 | [>](https://ngtrk.dc.beltelecom.by/ngtrk/smil:belarus2.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c0/Belarus_2_logo.svg/742px-Belarus_2_logo.svg.png"/> | Belarus2.by |
| 0   | Беларусь 3 | [>](https://ngtrk.dc.beltelecom.by/ngtrk/smil:belarus3.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Belarus_3_logo.svg/742px-Belarus_3_logo.svg.png"/> | Belarus3.by |
| 4   | ОНТ Ⓢ | [>](https://stream.dc.beltelecom.by/ont/ont/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3d/%D0%9B%D0%BE%D0%B3%D0%BE%D1%82%D0%B8%D0%BF_%D1%82%D0%B5%D0%BB%D0%B5%D0%BA%D0%B0%D0%BD%D0%B0%D0%BB%D0%B0_%C2%AB%D0%9E%D0%9D%D0%A2%C2%BB.svg/991px-%D0%9B%D0%BE%D0%B3%D0%BE%D1%82%D0%B8%D0%BF_%D1%82%D0%B5%D0%BB%D0%B5%D0%BA%D0%B0%D0%BD%D0%B0%D0%BB%D0%B0_%C2%AB%D0%9E%D0%9D%D0%A2%C2%BB.svg.png"/> | ONT.by |
| 0   | Беларусь 5 | [>](https://ngtrk.dc.beltelecom.by/ngtrk/smil:belarus5.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/Belarus_5_logo.svg/742px-Belarus_5_logo.svg.png"/> | Belarus5.by |
| 5   | СТВ | [>](https://ctv.dc.beltelecom.by/ctv/ctv.stream/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/33/%D0%9B%D0%BE%D0%B3%D0%BE%D1%82%D0%B8%D0%BF_%D0%B1%D0%B5%D0%BB%D0%BE%D1%80%D1%83%D1%81%D1%81%D0%BA%D0%BE%D0%B3%D0%BE_%D1%82%D0%B5%D0%BB%D0%B5%D0%BA%D0%B0%D0%BD%D0%B0%D0%BB%D0%B0_%C2%AB%D0%A1%D0%A2%D0%92%C2%BB.svg/640px-%D0%9B%D0%BE%D0%B3%D0%BE%D1%82%D0%B8%D0%BF_%D0%B1%D0%B5%D0%BB%D0%BE%D1%80%D1%83%D1%81%D1%81%D0%BA%D0%BE%D0%B3%D0%BE_%D1%82%D0%B5%D0%BB%D0%B5%D0%BA%D0%B0%D0%BD%D0%B0%D0%BB%D0%B0_%C2%AB%D0%A1%D0%A2%D0%92%C2%BB.svg.png"/> | STV.by |

<h2>DVB-S</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | Беларусь 24 | [>](https://ngtrk.dc.beltelecom.by/ngtrk/smil:belarus24.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/de/Belarus_24_logo.svg/742px-Belarus_24_logo.svg.png"/> | Belarus24.by |

<h2>Internet</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | Беларусь 5 Интернет | [>](https://ngtrk.dc.beltelecom.by/ngtrk/smil:belarus5int.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/rzPQ9Iz.png"/> | Belarus5Internet.by |

<h2>Other</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | 1Mus | [>](http://hz1.teleport.cc/HLS/HD.m3u8) | <img height="20" src="https://i.imgur.com/PozF9MT.png"/> | FirstMusicChannel.by |
| 2   | 8 Kanal Vitebsk Ⓢ | [>](http://95.46.208.8:24433/art) | <img height="20" src="https://i.imgur.com/tjwBSTF.jpg"/> | 8kanal.by |
| 3   | Belros Ⓢ | [>](https://live2.mediacdn.ru/sr1/tro/playlist.m3u8) | <img height="20" src="https://i.imgur.com/HWqxjGl.png"/> | BelRos.ru |
| 5   | Belarus 4 Vitebsk Ⓢ | [>](http://95.46.208.8:26258/belarus4) | <img height="20" src="https://i.imgur.com/TW6Ap71.png"/> | Belarus4Vitebsk.by |
| 7   | Hawe TV Vitebsk Ⓢ | [>](http://95.46.208.8:26259/nashe) | <img height="20" src="https://i.imgur.com/HOb5m5f.jpg"/> | NasheTV.by |
| 9   | Pervyy Muzykal'nyy BY Ⓢ | [>](http://rtmp.one.by:1200) | <img height="20" src="https://i.imgur.com/7tFiG6S.jpg"/> | FirstMusicChannel.by |
| 10  | Planeta RTR Ⓢ | [>](https://a3569455801-s26881.cdn.ngenix.net/live/smil:rtrp.smil/chunklist_b1600000.m3u8) | <img height="20" src="https://i.imgur.com/yqRuEJd.png"/> | RTRBelarus.by |
| 11  | Radio HIT Orsk | [>](http://hithd.camsh.orsk.ru/hls/hithd.m3u8) | <img height="20" src="https://i.imgur.com/e2RyN4r.jpg"/> | RadioHit.ru |
| 12  | Vitebsk Telekanal | [>](https://flu.vtv.by/tvt-non-by/tracks-v1a1/mono.m3u8) | <img height="20" src="https://i.imgur.com/FXAqELU.jpg"/> | Vitebsk.by |
