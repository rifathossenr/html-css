<h1>News</h1>

| #   | Channel         | Link  | Logo | EPG id |
|:---:|:---------------:|:-----:|:----:|:------:|
| 1  |    Sky News (UK)    |  [>](https://ythls.armelin.one/channel/UCoMdktPbSTixAyNGwb-UYkQ.m3u8)  |  <img height="20" src="https://d2n0069hmnqmmx.cloudfront.net/epgdata/1.0/newchanlogos/512/512/skychb1404.png"/>   |  SkyNewsInternational.uk  |
| 2  |      Euronews Ⓨ     |  [>](https://www.youtube.com/euronews/live)  |  <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Euronews_2022.svg/640px-Euronews_2022.svg.png"/>  |  EuronewsEnglish.fr  |
| 3  |     Africanews Ⓨ    |  [>](https://www.youtube.com/africanews/live)  |  <img height="20" src="https://i.imgur.com/xocvePC.png"/>  |  Africanews.cg  |
| 4  |      France 24 Ⓨ    |  [>](https://www.youtube.com/france24english/live)  |  <img height="20" src="https://i.imgur.com/61MSiq9.png"/>   |  France24English.fr  |
| 5  |         DW          |   [>](https://dwamdstream102.akamaized.net/hls/live/2015525/dwstream102/index.m3u8)  |  <img height="20" src="https://i.imgur.com/A1xzjOI.png"/>  |  DWEnglish.de  |
| 6  |     Al Jazeera      |   [>](https://live-hls-web-aje.getaj.net/AJE/index.m3u8)  |  <img height="20" src="https://i.imgur.com/BB93NQP.png"/>  |  AlJazeeraEnglish.qa |
| 7  |        CGTN         |  [>](https://news.cgtn.com/resource/live/english/cgtn-news.m3u8)  |  <img height="20" src="https://i.imgur.com/fMsJYzl.png"/>  |  CGTN.cn |
| 8  |     BBC News Ⓖ      |  [>](https://vs-hls-push-uk.live.fastly.md.bbci.co.uk/x=4/i=urn:bbc:pips:service:bbc_news_channel_hd/iptv_hd_abr_v1.m3u8)  |  <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/united-kingdom/bbc-news-uk.png"/>  |  BBCNews.uk  |
| 9  |    NBC News NOW     |  [>](https://dai2.xumo.com/amagi_hls_data_xumo1212A-xumo-nbcnewsnow/CDN/master.m3u8)  |  <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/united-kingdom/nbc-news-now-uk.png"/>  |  NBCNewsNOW.us |
| 10 |       Reuters       |  [>](https://reuters-reutersnow-1-nl.samsung.wurl.tv/playlist.m3u8)  |  <img height="20" src="https://i.imgur.com/6eQ2nCJ.png"/>  |  ReutersTV.us |
| 11 |    The Guardian     |  [>](https://rakuten-guardian-1-ie.samsung.wurl.tv/playlist.m3u8)  |  <img height="20" src="https://i.imgur.com/o9AYq9V.png"/>  |  TheGuardian.uk |
| 12 |      CBS News       |  [>](https://dai.google.com/linear/hls/event/Sid4xiTQTkCT1SLu6rjUSQ/master.m3u8)  |  <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/united-states/cbs-news-us.png"/>  |  CBSNews.us |
| 13 |    ABC News Live    |  [>](https://lnc-abc-news.tubi.video/index.m3u8)  |  <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/united-states/abc-news-live-hz-us.png"/>  |  ABCNewsLive.us |
| 14 |  LiveNOW from FOX   |  [>](https://lnc-fox-live-now.tubi.video/index.m3u8)  |  <img height="20" src="https://i.imgur.com/1JnyzHv.png"/>  |  LiveNOWFromFOX.us |
| 15 |  CBC News Network   |  [>](https://dai2.xumo.com/amagi_hls_data_xumo1212A-redboxcbcnews/CDN/playlist.m3u8)  |  <img height="20" src="https://i.imgur.com/SjTdhvJ.png"/>  |  CBCNewsNetwork.ca |
| 16 |     Ticker News     |  [>](https://cdn-uw2-prod.tsv2.amagi.tv/linear/amg01486-tickernews-tickernewsweb-ono/playlist.m3u8)  |  <img height="20" src="https://i.imgur.com/z7M0QxV.png"/>   |  tickerNews.au  |
| 17 |     India Today     |  [>](https://indiatodaylive.akamaized.net/hls/live/2014320/indiatoday/indiatodaylive/playlist.m3u8)  |  <img height="20" src="https://i.imgur.com/koFYddE.png"/>  |  IndiaToday.in |
| 18 |  Channel News Asia  |  [>](https://ythls.armelin.one/channel/UC83jt4dlz1Gjl58fzQrrKZg.m3u8)  |  <img height="20" src="https://i.imgur.com/xWglicB.png"/>  |  CNAInternational.sg  |
| 19 |    ABC News (AU) Ⓨ  |  [>](https://www.youtube.com/@abcnewsaustralia/live)  |  <img height="20" src="https://i.imgur.com/BrW7gk8.png"/>  |  ABCNews.au  |
| 20 |      NDTV 24x7      |  [>](https://ythls.armelin.one/channel/UCZFMm1mMw0F81Z37aaEzTUA.m3u8)  |  <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/india/ndtv-24x7-in.png"/>  |  NDTV24x7.in  |
| 21 |      TRT World      |  [>](https://ythls.armelin.one/channel/UC7fWeaHhqgM4Ry-RMpM2YYw.m3u8)  |  <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/TRT_World.svg/512px-TRT_World.svg.png"/>  |  TRTWorld.tr  |
| 22 |   NHK World Japan   |  [>](https://ythls.armelin.one/channel/UCSPEjw8F2nQDtmUKPFNF7_A.m3u8)  |  <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8d/NHK_World-Japan_TV.svg/512px-NHK_World-Japan_TV.svg.png"/>  |  NHKWorldJapan.jp  |
| 23 |      DD India       |  [>](https://ythls.armelin.one/channel/UCGDQNvybfDDeGTf4GtigXaw.m3u8)  |   <img height="20" src="https://i.imgur.com/45uptR8.png"/>  |  DDIndia.in  |
| 24 |        WION         |  [>](https://ythls.armelin.one/channel/UC_gUM8rL-Lrg6O3adPW9K1g.m3u8)  |   <img height="20" src="https://i.imgur.com/Wc5Z3iS.png"/>  |  WION.in  |
| 25 |       Taiwan+       |  [>](https://ythls.armelin.one/channel/UC7c6rvyAZLpKGk8ttVnpnLA.m3u8)  |   <img height="20" src="https://i.imgur.com/SfcZyqm.png"/>   |  TaiwanPlusTV.tw  |
| 26 | Metro Globe Network |  [>](https://edge.medcom.id/live-edge/smil:mgnch.smil/playlist.m3u8)  |   <img height="20" src="https://i.imgur.com/aiiinzg.png"/>  |  MetroGlobeNetwork.id  |
| 27 |      i24 News       |  [>](https://bcovlive-a.akamaihd.net/6e3dd61ac4c34d6f8fb9698b565b9f50/eu-central-1/5377161796001/playlist-all_dvr.m3u8) |  <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/79/LOGO_i24NEWS.png/512px-LOGO_i24NEWS.png"/>  |  i24NEWSEnglishWorld.il   |
| 28 |    Scripps News     |  [>](https://content.uplynk.com/channel/4bb4901b934c4e029fd4c1abfc766c37.m3u8)  |  <img height="20" src="https://i.imgur.com/UfN6aAi.png"/>  |  ScrippsNews.us  |
| 29 |      USA Today      |  [>](https://lnc-usa-today.tubi.video/playlist.m3u8)  |  <img height="20" src="https://i.imgur.com/37K0AZX.png"/>  |  USATODAY.us  |
| 30 |      TVC News Ⓨ    |  [>](https://www.youtube.com/tvcnewsnigeria/live)  |  <img height="20" src="https://i.imgur.com/jaSq18B.png"/>  |  TVCNews.ng  |
| 31 |     Channels 24 Ⓨ  |  [>](https://www.youtube.com/channelstelevision/live)  |  <img height="20" src="https://upload.wikimedia.org/wikipedia/en/7/76/Channels_TV.jpg"/>  |  Channels24.ng  |
| 32 |  Sky News Now (AU)  |  [>](https://i.mjh.nz/sky-news-now.m3u8)  |  <img height="20" src="https://upload.wikimedia.org/wikipedia/en/thumb/1/10/Sky_News_Australia_logo_-_2019.svg/512px-Sky_News_Australia_logo_-_2019.svg.png"/> |  SkyNewsAustralia.au  |
| 33 |     Global News     |  [>](https://live.corusdigitaldev.com/groupd/live/49a91e7f-1023-430f-8d66-561055f3d0f7/live.isml/.m3u8)  |  <img height="20" src="https://i.imgur.com/xk1QOhW.png"/>  |  GlobalNews.ca  |
| 34 |   Russia Today Ⓖ    |  [>](https://rt-glb.rttv.com/live/rtnews/playlist.m3u8)  |  <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Russia-today-logo.svg/512px-Russia-today-logo.svg.png"/>  |  RT.ru  |
| 35 |    Pluto TV News    |  [x]() | <img height="20" src="https://i.imgur.com/JdqA4r9.png"/>  |  PlutoTVNews.us |
| 36 |         CNN         |  [>](https://raw.githubusercontent.com/Alstruit/adaptive-streams/alstruit-10_23_us/streams/us/CNNUSA.us.m3u8)  |  <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/united-states/cnn-us.png"/>  |  CNN.us  |
| 37 |  CNN International  |  [>](https://turnerlive.warnermediacdn.com/hls/live/586495/cnngo/cnn_slate/VIDEO_0_3564000.m3u8)  |  <img height="20" src="https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/united-states/cnn-us.png"/>  |  CNNInternationalEurope.us |
| 38 |       GB News       |  [>](https://ythls.armelin.one/channel/UC0vn8ISa4LKMunLbzaXLnOQ.m3u8)  |  <img height="20" src="https://upload.wikimedia.org/wikipedia/en/thumb/3/35/GB_News_Logo.svg/512px-GB_News_Logo.svg.png"/>  |  GBNews.uk  |
| 39 |       TalkTV        |  [>](https://live-talktv-ssai.simplestreamcdn.com/v1/master/82267e84b9e5053b3fd0ade12cb1a146df74169a/talktv-live/index.m3u8)  |  <img height="20" src="https://i.imgur.com/KxHWpQB.png"/>  |  TalkTV.uk |
| 40 |      Joy News       |  [>](https://ythls.armelin.one/channel/UChd1DEecCRlxaa0-hvPACCw.m3u8)  |  <img height="20" src="https://i.imgur.com/kGuMNmR.png"/>  |  JoyNews.gh  |
| 41 |      SABC News      |  [>](https://sabconetanw.cdn.mangomolo.com/news/smil:news.stream.smil/chunklist_b250000_t64MjQwcA==.m3u8)  | <img height="20" src="https://i.imgur.com/H9q3Q9d.png"/>  |  SABCNews.gh  |

<h1>Business</h1>

|  #  |            Channel            |                               Link                                |                                                      Logo                                                      |       EPG id       |
|:---:|:-----------------------------:|:-----------------------------------------------------------------:|:--------------------------------------------------------------------------------------------------------------:|:------------------:|
| 101 |         Cheddar News          |          [>](https://dbrb49pjoymg4.cloudfront.net/10001/99991220/hls/index.m3u8?ads.xumo_channelId=99991220&ads._fw_ifa_type=dpid&ads._fw_did=43135081-0e2e-2a3f-b10c-4ade81d0e829&ads.amznappId=[AMZN_APP_ID]&ads.lat=[LAT]&ads.lon=[LON]&ads.os=[OS]&ads.osv=[OS_VERSION]&ads.asnw=&ads.caid=Cheddar&ads.csid=xumo_desktopweb_cheddar_ssai&ads._fw_is_lat=0&ads._fw_us_privacy=1YNN&ads._fw_coppa=0&ads.genre=News&ads._fw_content_category=IAB12&ads._fw_content_language=en&ads._fw_content_genre=News&ads._fw_content_rating=TV-PG&ads.xumo_contentId=161&ads.xumo_contentName=Cheddar&ads.xumo_providerId=161&ads.xumo_providerName=Cheddar&ads._fw_deviceMake=&ads._fw_device_model=&ads.channelId=99991220&ads.xumo_platform=desktopweb&ads.site_id=26840&ads.appName=xumo&ads.appVersion=2.18.0&ads._fw_app_bundle=&ads._fw_app_store_url=&ads.site_name=XumoPlay&ads.site_page=https%253A%252F%252Fplay.xumo.com)           |                            <img height="20" src="https://i.imgur.com/tuP9GW8.png"/>                            |   CheddarNews.us   |
| 102 |         Bloomberg TV+         | [>](https://bloomberg.com/media-manifest/streams/phoenix-us.m3u8) |                            <img height="20" src="https://i.imgur.com/xGlToly.png"/>                            | BloombergTVPlus.us |
| 103 |   Bloomberg Television (US)   |       [>](https://bloomberg.com/media-manifest/streams/us.m3u8)       |           <img height="20" src="https://i.imgur.com/OuogLHx.png"/>           |  BloombergTV.us  |
| 104 | Bloomberg Television (Europe) |       [>](https://bloomberg.com/media-manifest/streams/eu.m3u8)       |           <img height="20" src="https://i.imgur.com/OuogLHx.png"/>           |  BloombergTVEurope.uk  |
| 105 |        Yahoo! Finance         |     [>](https://d1ewctnvcwvvvu.cloudfront.net/playlist.m3u8)      |                            <img height="20" src="https://i.imgur.com/43oHsHL.png"/>                            |  YahooFinance.us   |
| 106 |          CNBC Europe          |       [>](https://amg01079-nbcuuk-amg01079c1-samsung-es-1261.playouts.now.amagi.tv/playlist/amg01079-nbcuukfast-cnbcpe-samsunges/playlist.m3u8)       |           <img height="20" src="https://d2n0069hmnqmmx.cloudfront.net/epgdata/1.0/newchanlogos/512/512/skychb1088.png"/>           |    CNBCEurope.uk     |
| 107 |        CNBC Indonesia         |       [>](https://live.cnbcindonesia.com/livecnbc/smil:cnbctv.smil/master.m3u8)       |           <img height="20" src="https://i.imgur.com/bUfeG7Y.png"/>           |    CNBCIndonesia.id     |
| 108 |            Ausbiz             |       [>](https://d9quh89lh7dtw.cloudfront.net/public-output/index.m3u8)       |           <img height="20" src="https://i.imgur.com/8vGGdB0.png"/>           |   AusbizTV.au   |
| 109 |           Moconomy            |       [>](https://amogonetworx-moconomy-2-us.tcl.wurl.tv/playlist.m3u8)       |           <img height="20" src="https://i.imgur.com/GvqbLZB.png"/>           |  MoconomyEconomyFinanceInfotainment.us  |

<h1>Weather</h1>

| #   | Channel         | Link  | Logo | EPG id |
|:---:|:---------------:|:-----:|:----:|:------:|
| 201 | AccuWeather NOW |  [>](https://cdn-ue1-prod.tsv2.amagi.tv/linear/amg00684-accuweather-accuweather-plex/playlist.m3u8)  |  <img height="20" src="https://i.imgur.com/M8wbVYK.png"/>  |  AccuWeatherNOW.us |
| 202 |   Fox Weather   |  [>](https://lnc-fox-weather.tubi.video/index.m3u8)  |  <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Fox_Weather_logo.svg/512px-Fox_Weather_logo.svg.png"/>  |  FoxWeather.us  |
| 203 |    KTCA-DT5     |  [>](https://api.new.livestream.com/accounts/12638076/events/8488790/live.m3u8)  |  <img height="20" src="https://upload.wikimedia.org/wikipedia/en/b/be/Twin_Cities_Public_Television_logo_%28PBS%29.png"/>  |  KTCADT5.us  |
| 204 |    WeatherNation    | [>](http://cfd-v4-service-channel-stitcher-use1-1.prd.pluto.tv/stitch/hls/channel/5d2cb7ac552e3773bc48982e/master.m3u8?appName=web&appVersion=unknown&clientTime=0&deviceDNT=0&deviceId=6c2d1028-30d3-11ef-9cf5-e9ddff8ff496&deviceMake=Chrome&deviceModel=web&deviceType=web&deviceVersion=unknown&includeExtendedEvents=false&serverSideAds=false&sid=dcca8395-396e-4be0-9049-564f29c5ac9b) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/de/WeatherNation_Logo.svg/512px-WeatherNation_Logo.svg.png"/> | WeatherNation.us  |
| 205 | The Weather Network | [>](https://d3f6rv2ihfj09x.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-4l4ssesb90374-ssai-prd/playlist.m3u8?ads.device_did=%7BPSID%7D&ads.device_dnt=%7BTARGETOPT%7D&ads.app_domain=%7BAPP_DOMAIN%7D&ads.app_name=%7BAPP_NAME%7D) | <img height="20" src="https://upload.wikimedia.org/wikipedia/en/thumb/b/bf/TWN_Logo_2011.svg/2560px-TWN_Logo_2011.svg.png"/> | TheWeatherNetwork.ca  |
| 206 |  Sky News Weather Ⓖ  | [>](https://distro001-gb-hls1-prd.delivery.skycdp.com/easel_cdn/ngrp:weather_loop.stream_all/playlist.m3u8) | <img height="20" src="https://pbs.twimg.com/profile_images/1604994875459518464/lGt2wEqM_400x400.jpg"/> | SkyNewsWeather.uk  |


