<h1>India</h1>

<h2>DVB-T</h2>

https://en.wikipedia.org/wiki/List_of_HD_channels_in_India
https://en.wikipedia.org/wiki/List_of_4K_channels_in_India

| #   | Channel          | Link  | Logo | EPG id |
|:---:|:----------------:|:-----:|:----:|:------:|
| 1   | NDTV India       | [>](https://ndtvindiaelemarchana.akamaized.net/hls/live/2003679/ndtvindia/master.m3u8) | <img height="20" src="https://i.imgur.com/QjJYohG.png" /> | NDTVIndia.in |
| 2   | ABP News         | [>](https://abplivetv.akamaized.net/hls/live/2043010/hindi/master.m3u8) | <img height="20" src="https://i.imgur.com/DKHUFVQ.png" /> | ABPNews.in |
| 3   | DD National Ⓨ   | [>](https://www.youtube.com/doordarshan/live) | <img height="20" src="https://i.imgur.com/MohlE5B.png" /> | DDNational.in |
| 4   | DD News Ⓨ       | [>](https://www.youtube.com/c/ddnews/live) | <img height="20" src="https://i.imgur.com/znnVCEf.png" /> | DDNews.in |
| 5   | DD India Ⓨ      | [>](https://www.youtube.com/DDIndia/live) | <img height="20" src="https://i.imgur.com/45uptR8.png" /> | DDIndia.in |
| 6   | DD Bharati Ⓨ    | [>](https://www.youtube.com/@ddbharati/live) | <img height="20" src="https://i.imgur.com/4tfUIEo.png" /> | DDBharati.in |
| 7   | DD Kisan Ⓨ      | [>](https://www.youtube.com/@DDKisan/live) | <img height="20" src="https://i.imgur.com/x56WJEa.png" /> | DDKisan.in |
| 8   | DD Urdu Ⓨ       | [>](https://www.youtube.com/@DDUrdu/live) | <img height="20" src="https://i.imgur.com/OiQPS34.png" /> | DDUrdu.in |
| 9   | India Today Ⓨ   | [>](https://www.youtube.com/watch?v=sYZtOFzM78M) | <img height="20" src="https://i.imgur.com/C7KK3Fd.png" /> | IndiaToday.in |


<h2>Invalid</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
