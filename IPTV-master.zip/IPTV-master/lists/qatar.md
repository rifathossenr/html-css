<h1>Qatar</h1>

| #   | Channel    | Link  | Logo | EPG id |
|:---:|:----------:|:-----:|:----:|:------:|
| 1   | Qatar Television | [>](https://qatartv.akamaized.net/hls/live/2026573/qtv1/master.m3u8) | <img height="20" src="https://i.imgur.com/N5RB4sp.png"/> | QatarTelevision.qa |
| 2   | Qatar Television 2 | [>](https://qatartv.akamaized.net/hls/live/2026573/qtv1/master.m3u8) | <img height="20" src="https://i.imgur.com/iWJxDUm.png"/> | QatarTelevision2.qa |
| 3   | Al Rayyan | [>](https://alrayyancdn.vidgyor.com/pub-noalrayy3pwz0l/liveabr/playlist_dvr.m3u8) | <img height="20" src="https://i.imgur.com/Ts3RjTV.png"/> | AlRayyanTV.qa |
| 4   | Al Rayyan Old TV | [>](https://alrayyancdn.vidgyor.com/pub-nooldraybinbdh/liveabr/playlist_dvr.m3u8) | <img height="20" src="https://i.imgur.com/4qB5iN0.png"/> | AlRayyanOldTV.qa |
| 5   | Al Jazeera Mubasher | [>](https://live-hls-web-ajm.getaj.net/AJM/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/en/9/90/Al_Jazeera_Mubasher_logo.png"/> | AlJazeeraMubasher.qa |
| 6   | Alkass One | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=AlkassOne) | <img height="20" src="https://i.imgur.com/10mmlha.png"/> | AlkassOne.qa |
| 7   | Alkass Two | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=AlkassTwo) | <img height="20" src="https://i.imgur.com/8w61kFX.png"/> | AlkassTwo.qa |
| 8   | Alkass Three | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=AlkassThree) | <img height="20" src="https://i.imgur.com/d57BdFh.png"/> | AlkassThree.qa |
| 9   | Alkass Four | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=AlkassFour) | <img height="20" src="https://i.imgur.com/iDL65Wu.png"/> | AlkassFour.qa |
| 9   | Al Araby TV | [>](https://alaraby.cdn.octivid.com/alaraby/smil:alaraby.stream.smil/chunklist.m3u8) | <img height="20" src="https://i.imgur.com/YMqWEe4.png"/> | AlkassFour.qa |
