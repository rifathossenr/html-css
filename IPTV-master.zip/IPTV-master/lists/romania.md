<h1>Romania</h1>

https://en.wikipedia.org/wiki/List_of_television_stations_in_Romania

<h2>National</h2>

| #   | Channel           | Link  | Logo | EPG id|
|:---:|:-----------------:|:-----:|:----:|:-----:|
| 1   | TVR 1 Ⓖ           | [>](https://mn-nl.mncdn.com/tvr1_hd_live/smil:tvr1_hd_live.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/CKQ7mpB.png"> | TVR1.ro |
| 2   | TVR 2 Ⓖ           | [>](https://mn-nl.mncdn.com/tvr2_test/smil:tvr2_test.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/4/4c/TVR_2_2022_logo.png"> | TVR2.ro |
| 3   | TVR 3 Ⓖ           | [>](https://mn-nl.mncdn.com/tvr3_test/smil:tvr3_test.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/0/0d/TVR3_2022.png"> | TVR3.ro |
| 4   | TVR Info Ⓖ        | [>](https://mn-nl.mncdn.com/tvrinfo/tvrinfo_mjuypp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/7oE7ThR.png"> | TVRInfo.ro |
| 5   | TVR International Ⓖ | [>](https://mn-nl.mncdn.com/tvri_test/smil:tvri_test.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/AlW8jyl.png"> | TVRInternational.ro |
| 6   | Pro TV            | [>](https://cmero-ott-live.ssl.cdn.cra.cz/channels/cme-ro-voyo-news/playlist.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/aKAfKtW.png" /> | ProTV.ro |
| 7   | Prima TV          | [>](https://stream1.1616.ro:1945/prima/livestream/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5d/Prima_TV_%28Rumaenien%29_Logo.svg/512px-Prima_TV_%28Rumaenien%29_Logo.svg.png"/> | PrimaTV.ro |
| 8   | România TV Ⓖ      | [>](https://livestream.romaniatv.net/clients/romaniatv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/ZIfEp5I.png"/> | RomaniaTV.ro |
| 9   | Telestar1         | [>](http://89.47.97.15/telestar/telestar.m3u8) | <img height="20" src="https://i.imgur.com/UZQjEsd.png"/> | Telestar1.ro |
| 10  | Euronews România Ⓨ | [>](https://www.youtube.com/euronewsro/live) | <img height="20" src="https://i.imgur.com/jUOVUXt.png"/> | EuronewsRomania.ro |

<h2>Local</h2>

| #   | Channel        | Link  | Logo | EPG id|
|:---:|:--------------:|:-----:|:----:|:-----:|
| 1   | TVR Cluj Ⓖ     | [>](https://mn-nl.mncdn.com/tvrcluj_new/smil:tvrcluj_new.smil/index.m3u8) | <img height="20" src="https://i.imgur.com/8DqsGHO.png"/> | TVRCluj.ro |
| 2   | TVR Craiova Ⓖ  | [>](https://mn-nl.mncdn.com/tvrcraiova_new/smil:tvrcraiova_new.smil/index.m3u8) | <img height="20" src="https://i.imgur.com/vxWbQiy.png"/> | TVRCraiova.ro |
| 3   | TVR Iași Ⓖ     | [>](https://mn-nl.mncdn.com/tvriasi_new/smil:tvriasi_new.smil/index.m3u8) | <img height="20" src="https://i.imgur.com/Kxkihds.png"/> | TVRIasi.ro |
| 4   | TVR Timișoara Ⓖ | [>](https://mn-nl.mncdn.com/tvrtimisoara_new/smil:tvrtimisoara_new.smil/index.m3u8) | <img height="20" src="https://i.imgur.com/Db3DV6H.png"/> | TVRTimisoara.ro |
| 5   | TVR Tîrgu-Mureș Ⓖ | [>](https://mn-nl.mncdn.com/tvrtgmures_new/smil:tvrtgmures_new.smil/index.m3u8) | <img height="20" src="https://i.imgur.com/9Hptdqj.png"/> | TVRTarguMures.ro |
