<h1>Austria</h1>

<h2>DVB-T</h2>

https://wiki.ubuntuusers.de/Internet-TV/Stationen

| #  | Channel        | Link  | Logo | EPG id |
|:--:|:--------------:|:-----:|:----:|:------:|
| 1  | ORF 1 Ⓖ | [>](https://orf1.mdn.ors.at/out/u/orf1/q8c/manifest.m3u8) | <img height="20" src="https://i.imgur.com/ft2LuRl.jpg"/> | ORF1.at |
| 2  | ORF 2 Ⓖ | [>](https://orf2.mdn.ors.at/out/u/orf2/q8c/manifest.m3u8) | <img height="20" src="https://i.imgur.com/yPVDaXv.png"/> | ORF2.at |
| 3  | ORF III Ⓖ | [>](https://orf3.mdn.ors.at/out/u/orf3/q8c/manifest.m3u8) | <img height="20" src="https://i.imgur.com/6BuiUE7.png"/> | ORFIII.at |
| 4  | ORF Sport + Ⓖ | [>](https://orfs.mdn.ors.at/out/u/orfs/q8c/manifest.m3u8) | <img height="20" src="https://i.imgur.com/MVNZ4gf.png"/> | ORFSportPlus.at |
| 5  | Servus TV Ⓖ | [>](https://rbmn-live.akamaized.net/hls/live/2002825/geoSTVATweb/master.m3u8) | <img height="20" src="https://i.imgur.com/zDWhSxq.png"/> | ServusTVOsterreich.at |
| 6  | oe24     | [>](https://varoe24live.sf.apa.at/oe24-live1/oe24.smil/chunklist_b1900000.m3u8) | <img height="20" src="https://i.imgur.com/8UTkcPn.png"/> | Oe24TV.at |
| 7  | W24      | [>](https://ms01.w24.at/W24/smil:liveevent.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/PGb4wYw.png"/> | W24.at |
| 8  | P3TV      | [>](http://p3-6.mov.at:1935/live/weekstream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/1sPhZ57.png"/> | P3tv.at |
| 9  | RTV      | [>](http://iptv.rtv-ooe.at/stream.m3u8) | <img height="20" src="https://i.imgur.com/oD7GQxT.png"/> | RTV.at |
| 10 | RTS Ⓖ | [>](https://58b42f6c8c9bf.streamlock.net:8080/live/RTS2015/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Bhv7lvy.png"/> | TVTV.at |
| 11 | Tirol TV Ⓖ | [>](http://lb.hd-livestream.de:1935/live/TirolTV/playlist.m3u8) | <img height="20" src="https://i.imgur.com/1E7Nflo.jpg"/> | TirolTV.at |
| 12 | R9      | [>](https://ms01.w24.at/R9/smil:liveeventR9.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/2fxVYsL.jpg"/> | R9.at |
