<h1>Documentaries (EN)</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | CGTN Documentary English Ⓢ | [>](https://news.cgtn.com/resource/live/document/cgtn-doc.m3u8) | <img height="20" src="https://i.imgur.com/JHv0WxM.png"/> | CGTNDocumentary.cn |
| 0   | RT Documentary English Ⓖ | [>](https://rt-rtd.rttv.com/dvr/rtdoc/playlist.m3u8) | <img height="20" src="https://i.imgur.com/ZEi1Wgn.png"/> | RTDoc.ru |
| 0   | Peer TV South Tyrol | [>](https://iptv.peer.biz/live/peertv-en.m3u8)| <img height="20" src="https://www.peer.biz/peertv-iptv/peer-tv-south-tyrol.png"/> | PeerTV.it |
