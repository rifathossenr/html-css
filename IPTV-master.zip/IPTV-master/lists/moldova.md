<h1>Moldova</h1>

<h2>DVB-T</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Moldova 1 | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=Moldova1) | <img height="20" src="https://i.imgur.com/ZbQY56v.png"/> | Moldova1.md |
| 2   | Moldova 2 | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=Moldova2) | <img height="20" src="https://i.imgur.com/Hv6Nk8A.png"/> | Moldova2.md |
| 3   | Publika TV | [>](https://livebeta.publika.md/LIVE/P/6810.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/b/b7/Publika_logo_%282017%29.png"/> | PublikaTV.md |
| 4   | Vocea Basarabiei | [>](https://storage.voceabasarabiei.md/hls/vocea_basarabiei.m3u8) | <img height="20" src="https://i.imgur.com/irP8QLs.png"/> | VoceaBasarabieiTV.md |
| 4   | Canal 2 Ⓖ | [>](https://livebeta.publika.md/LIVE/2/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/ro/7/7f/Logo_Canal_2.png"/> | Canal2.md |
| 5   | Canal 3 Ⓖ | [>](https://livebeta.publika.md/LIVE/3/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Canal_3.svg/640px-Canal_3.svg.png"/> | Canal3.md |
| 6   | Prime Ⓖ | [>](https://livebeta.publika.md/LIVE/1/600.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/7/70/Prime.png"/> | Prime.md |
| 7   | TVR Moldova Ⓖ | [>](https://mn-nl.mncdn.com/tvrmoldova_new/smil:tvrmoldova_new.smil/chunklist_b6096000.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/TVR_Moldova_Logo_2022.svg/640px-TVR_Moldova_Logo_2022.svg.png"/> | TVRMoldova.md |

<h2>Regional</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Sor TV | [>](http://188.237.212.16:8888/live/cameraFeed.m3u8) | <img height="20" src="https://i.imgur.com/BcfZgD8.png"/> | SorTV.md |
| 2   | Bălți TV | [>](https://hls.btv.md/hls/live2.m3u8) | <img height="20" src="https://i.imgur.com/S1vEqZp.png"/> | BaltiTV.md |
