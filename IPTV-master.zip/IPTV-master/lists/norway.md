<h1>Norway</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | NRK1 Ⓖ | [>](https://nrk-nrk1.akamaized.net/21/0/hls/nrk_1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/9tj8ds7.png"/> | NRK1.no |
| 2   | NRK2 Ⓖ | [>](https://nrk-nrk2.akamaized.net/22/0/hls/nrk_2/playlist.m3u8) | <img height="20" src="https://i.imgur.com/SiAdoK9.png"/> | NRK2.no |
| 3   | NRK3 Ⓖ | [>](https://nrk-nrk3.akamaized.net/23/0/hls/nrk_3/playlist.m3u8) | <img height="20" src="https://i.imgur.com/TNhV2I7.png"/> | NRK3.no |
| 6   | NRK Super Ⓖ | [>](https://nrk-nrksuper.akamaized.net/23/0/hls/nrk_super/playlist.m3u8) | <img height="20" src="https://i.imgur.com/xIATe2T.png"/> | NRKSuper.no |
| 12   | TV 2 Sport 1     | [>](https://ws31-hls-live.akamaized.net/out/u/1416253.m3u8) | <img height="20" src="https://i.imgur.com/asKHqNZ.png"/> | TV2Sport1.no |
| 22   | TV 2 Nyheter     | [>](https://ws15-hls-live.akamaized.net/out/u/1153546.m3u8) | <img height="20" src="https://i.imgur.com/kkKoY6s.png"/> | TV2Nyhetskanalen.no |
| 50   | Frikanalen     | [>](https://frikanalen.no/stream/index.m3u8) | <img height="20" src="https://i.imgur.com/rY3Owxl.png"/> | Frikanalen.no |
| 109   | Kanal 10 Norge | [>](https://player-api.new.livestream.com/accounts/29308686/events/10787545/broadcasts/235454817.secure.m3u8) | <img height="20" src="https://i.imgur.com/2fOcZfK.png"/> | Kanal10Norway.no |
